import React from 'react'
import Tvnavbar from '../components/Tvnavbar'

export default function Seasons() {
  return (
    <div>
        <div>
            <Tvnavbar/>
        </div>
        <div>
            
        </div>
    </div>
  )
}
